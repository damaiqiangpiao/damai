#!/system/bin/sh
#官宣粉丝交流群：938499734
#ColorOS玩机交流群：872254795
#禁止商用*转载请获取作者许可
MODDIR=${0%/*}
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 0 > /proc/sys/fs/inotify/max_queued_events
echo 0 > /proc/sys/fs/verity/require_signatures
settings delete global adb_enabled
settings delete global development_settings_enabled
settings delete global hidden_api_policy
settings delete global clockwork_sysui_package
settings delete global hidden_api_policy_p_apps
settings delete global hidden_api_policy_pre_p_apps

